/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.*;
public class Basic {
    public static ArrayList<User> users = new ArrayList<>();
    public static List<Property> properties = new ArrayList<>();
    private static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private HashMap<Date, String> propertyInspections = new HashMap<>();



    /**
     * this method displays the menu and gets the user input
     */
    public void menu(){
        Scanner scanner = new Scanner(System.in); //use scanner to get the input from the user.
        int choice;
        int userId;
        int propertyId;
        //do while loop is use for displaying the menu until the user decides to exit
        do{
            System.out.println("\n---- Menu ----");
            System.out.println("1. Add User");
            System.out.println("2. Delete User");
            System.out.println("3. Get User Details");
            System.out.println("4. Add Property");
            System.out.println("5. Delete Property");
            System.out.println("6. Get Property Details");
            System.out.println("7. Add Booking");
            System.out.println("8. Get User Booking");
            System.out.println("9. Get Booking Cost");
            System.out.println("10. List Users");
            System.out.println("11. List Properties");
            System.out.println("12. Get Discount For User");
            System.out.println("13. Add Inspection To Property");
            System.out.println("14. Compare Property Prices Per Day");
            System.out.println("15. Exit");
            System.out.println("Enter choice (1-15)>>");
            choice = scanner.nextInt();
            //use switch for executing the appropriate method
            switch (choice){
                case 1:
                    addUser();
                    System.out.println("A new user is added");
                    break;
                case 2:
                    System.out.println("Enter User ID to delete:");
                    userId= scanner.nextInt();
                    deleteUser(userId);
                    System.out.println("A new user is added");
                    break;
                case 3:
                    System.out.println("Enter User ID to get details:");
                    userId= scanner.nextInt();
                    getUserDetails(userId);
                    break;
                case 4:
                    //add property
                    addProperty();

                    break;
                case 5:
                    //delete property
                    System.out.println("Enter Property ID to delete a property:");
                    propertyId= scanner.nextInt();
                    deleteProperty(propertyId);
                    break;
                case 6:
                    //get property details
                    System.out.println("Enter Property ID to get details:");
                    propertyId= scanner.nextInt();
                    getPropertyDetails(propertyId);
                    break;
                case 7:
                    //add booking
                    System.out.println("Enter user id");
                    userId= scanner.nextInt();
                    System.out.println("Enter property id");
                    propertyId=scanner.nextInt();
                    addBooking(userId,propertyId);
                    break;
                case 8:
                    //get booking cost
                    System.out.println("Enter user id for getting the booking cost");
                    userId= scanner.nextInt();
                    System.out.println("Enter property id for getting the booking cost");
                    propertyId=scanner.nextInt();
                    getBookingCost(userId,propertyId);
                    break;
                case 9:
                    //get user Booking
                    System.out.println("Enter user id for user Booking");
                    userId= scanner.nextInt();
                    getUserBooking(userId);
                    break;
                case 10:
                    listUsers();
                    break;
                case 11:
                    //list properties
                    listProperties();
                    break;
                case 12:
                    //get discount for user
                    System.out.println("Enter User ID to get the discount for user:");
                    userId= scanner.nextInt();
                    getDiscountForUser(userId);
                    break;
                case 13:
                    //add inspection to property
                    System.out.println("Enter Property ID to inspection");
                    propertyId= scanner.nextInt();
                    System.out.println("Enter the text for inspection");
                    String text = scanner.nextLine();
                    addInspectionToProperty(propertyId,text);
                    break;
                case 14:
                    //compare property prices per day
                    System.out.println("Enter property id 1");
                    int Id1 = scanner.nextInt();
                    System.out.println("Enter property id 2:");
                    int Id2 = scanner.nextInt();
                    comparePropertyPricesPerDay(Id1,Id2);
                    break;
                case 15:
                    //exit method
                    exit();
                    break;
                default:
                    //print a proper error message if the user enters an invalid choice. And then ask again.
                    System.out.println("Invalid choice. Please enter a number between 1 and 15.");
            }
        }
        while (choice!=12);
        scanner.close();
    }

    /**
     * this method adds a new user
     * @return User
     */
    public User addUser()
    {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter user type (host/standard/gold):");
        String userType = scanner.nextLine().toLowerCase();
        System.out.println("Enter first name:");
        String firstName = scanner.nextLine();
        System.out.println("Enter last name:");
        String lastName = scanner.nextLine();
        System.out.println("Enter date of birth (dd/mm/yyyy):");
        String dobString = scanner.nextLine();
        System.out.println("Enter registration date (dd/mm/yyyy):");
        String regDateString = scanner.nextLine();
        Date dob;
        Date regDate;
        try {
            dob = sdf.parse(dobString);
            regDate = sdf.parse(regDateString);
        } catch (Exception e) {
            System.out.println("Invalid date format. Please try again using dd/mm/yyyy format.");
            return null; // Exiting the method if the date parsing fails
        }
        int userId = generateUniqueId();
        // Check for duplicate user IDs before creating the new user
        if (users.stream().anyMatch(u -> u.getUserId() == userId)) {
            System.out.println("A user with this ID already exists. Please try again.");
            return null; // Exit the method if there is a duplicate id
        }
        // Get preferredPaymentMethod for Customer subclasses
        String preferredPaymentMethod = "";
        if (userType.equals("standard") || userType.equals("gold")) {
            System.out.println("Enter preferred payment method:");
            preferredPaymentMethod = scanner.nextLine();
        }
        User user = null;

        switch (userType) {
            case "host":
                user = new Host();
                System.out.println("Enter tax number:");
                double taxNumber = scanner.nextDouble();
                scanner.nextLine();
                ((Host)user).setTaxNumber(taxNumber);
                break;

            case "standard":
                Standard standard = new Standard(userId, dob, firstName, lastName, regDate, preferredPaymentMethod);
                users.add(standard);
                System.out.println("Standard customer added successfully with ID: " + userId);
                break;
            case "gold":
                System.out.println("Enter gold level (1-3):");
                int goldLevel = scanner.nextInt();
                scanner.nextLine(); // Consume the newline left by nextInt
                while (goldLevel < 1 || goldLevel > 3) {
                    System.out.println("Invalid level. Please enter a level between 1 and 3:");
                    goldLevel = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline left by nextInt
                }
                Gold gold = new Gold(userId, dob, firstName, lastName, regDate, preferredPaymentMethod, goldLevel);
                users.add(gold);
                System.out.println("Gold customer added successfully with ID: " + userId);
                break;

            default:
                System.out.println("Invalid user type.");
                return null; // Exit the method if the user type is not recognized
        }

        scanner.close();
        return user;

    }

    /**
     * this method calculates a unique id starting from 1 and adding 1 to it.
     * @return unique id for user
     */
    private int generateUniqueId(){
        int id = 1; // Start with ID 1
        for (User user : users) {
            if (user.getUserId() >= id) {
                id = user.getUserId() + 1; // Ensure the ID is unique
            }
        }
        return id; // Return the unique ID
    }

    /**
     * this method gets the user id and deletes that user id
     * @param userID
     */
    public void deleteUser(int userID) {
        Iterator<User> iterator = users.iterator();
        while (iterator.hasNext()) {
            User user = iterator.next();
            if (user.getUserId() == userID) {
                iterator.remove();
                System.out.println("User with ID " + userID + " has been deleted.");
                return;
            }
        }
        System.out.println("User with ID " + userID + " does not exist.");
    }

    /**
     * this method displays the user details with the given user id
     * @param userId
     */
    public void getUserDetails(int userId) {
        for (User user : users) {
            if (user.getUserId() == userId) {
                System.out.println(user.toString()); // Display user details
                return;
            }
        }
        System.out.println("No user found with ID " + userId + ".");
    }

    /**
     * this method displays all the users
     */
    public void listUsers() {
        if (users.isEmpty()) {
            System.out.println("No users available.");
        } else {
            for (User user : users) {
                System.out.println(user.toString());
            }
        }
    }

    /**
     * this method calculates the DiscountForUser
     * @param userId
     * @return double DiscountForUser
     */
    public double getDiscountForUser(int userId) {
        for (User user : users) {
            if (user.getUserId() == userId) {
                if (user instanceof Gold goldUser) {
                    return goldUser.getDiscountPercentage();
                } else if (user instanceof Standard standardUser) {
                    return standardUser.getDiscountPercentage();
                } else {
                    // If the user is neither Gold nor Standard, return 0
                    return 0.0;
                }
            }
        }
        System.out.println("No user found with ID " + userId + ".");
        return 0.0; // Return 0.0 if no user is found
    }

    /**
     * this method adds a new property
     */
    public void addProperty(){
        Property property;
        Scanner scanner = new Scanner(System.in);
        int finalPropertyId;
        //first check the host if it excites
        System.out.println("Enter host's user ID:"); //get the host user ID to check
        int hostUserId = scanner.nextInt();
        //check for host id
        Host host = findHost(hostUserId);
        if (host == null) {
            System.out.println("Error! Host with that id could not be found .");
            return;
        }

        System.out.println("Enter property type (shared/full):");
        String propertyType = scanner.nextLine().toLowerCase();

        while (true) {
            System.out.println("Enter Property ID:");
            int propertyId = scanner.nextInt();
            if (properties.stream().anyMatch(p -> p.getPropertyId() == propertyId)) {
                System.out.println("A property with this ID already exists. Please enter a different ID.");
            } else {
                finalPropertyId = propertyId;
                break; // Exit the loop if the ID is unique
            }
        }
        System.out.println("Enter number of bedrooms:");
        int noBedRooms = scanner.nextInt();
        System.out.println("Enter number of rooms:");
        int noRooms = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter city:");
        String city = scanner.nextLine();
        System.out.println("Enter price per day:");
        double pricePerDay = scanner.nextDouble();

        if ("full".equals(propertyType)) {
            System.out.println("Enter property size in square meters:");
            double propertySize = scanner.nextDouble();
            property = new FullProperty(); //the constructor without parameters. I will use getters and setters
            ((FullProperty) property).setSize(propertySize);
        } else { //shared property
            property = new SharedProperty(); // constructor without parameters I will use getters and setters
        }
        // Setting common details with setters of the class Property
        property.setPropertyId(finalPropertyId);
        property.setNoRooms(noRooms);
        property.setNoBedRooms(noBedRooms);
        property.setCity(city);
        property.setPricePerDay(pricePerDay);
        property.setHost(host);
        properties.add(property);
        System.out.println("Property added successfully.");
        scanner.close();
    }

    /**
     * this method finds a new host from the user id
     * @param hostUserId
     * @return
     */
    private Host findHost(int hostUserId) {
        // Check if the host already exists
        for (User user : users) {
            if (user instanceof Host && user.getUserId() == hostUserId) {
                return (Host) user;
            }
        }

        return null;
    }

    /**
     * this method deletes the property from its id
     * @param propertyId
     */
    public void deleteProperty(int propertyId){
        Iterator<Property> iterator = properties.iterator();
        boolean isPropertyFound = false;

        while (iterator.hasNext()) {
            Property property = iterator.next();
            if (property.getPropertyId() == propertyId) {
                iterator.remove();
                isPropertyFound = true;
                System.out.println("Property with ID " + propertyId + " has been deleted.");
                break; // Exit the loop once the property is found and removed
            }
        }

        if (!isPropertyFound) {
            System.out.println("Property with ID " + propertyId + " does not exist.");
        }
    }

    /**
     * this method displays the property details from its id
     * @param propertyID
     */
    public void getPropertyDetails(int propertyID) {
        for (Property property : properties) {
            if (property.getPropertyId() == propertyID) {
                System.out.println(property.toString()); // Display property details
                return;
            }
        }
        System.out.println("No property found with ID " + propertyID + ".");
    }

    /**
     * this method displays all the properties
     */
    public void listProperties(){
        if (properties.isEmpty()) {
            System.out.println("No properties available.");
        } else {
            for (Property property : properties) {
                System.out.println(property.toString()); // or just System.out.println(property);
            }
        }

    }

    /**
     * this method adds a new inspection to a property
     * @param propertyId
     * @param inspectionText
     */
    public void addInspectionToProperty(int propertyId, String inspectionText) {
        // get the property based on the propertyId
        Property property = getPropertyById(propertyId);

        // Check if the property exists
        if (property == null) {
            System.out.println("Property with ID " + propertyId + " not found.");
            return;
        }

        // Get the current system date
        Date currentDate = new Date();

        // Format the date as "dd MM yyyy"
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MM yyyy");
        String formattedDate = dateFormat.format(currentDate);

        // Add the inspection text to the property's inspections HashMap
        property.addInspection(currentDate, inspectionText);

        // give the confirmation message
        System.out.println("Inspection added to property " + propertyId + " on " + formattedDate + ": " + inspectionText);
    }

    /**
     * this method gets the property from its id
     * @param propertyId
     * @return property
     */

    private Property getPropertyById(int propertyId) {
        for (Property property : properties) {
            if (property.getPropertyId() == propertyId) {
                return property;
            }
        }
        return null;
    }

    /**
     * this method adds a booking from user and property id
     * @param userId
     * @param propertyId
     */
    private void addBooking(int userId, int propertyId){

        User user = null;
        for (User u : users) {
            if (u.getUserId() == userId) {
                user = u;
                break;
            }
        }

        if (user == null) {
            System.out.println("Error: No user found with ID " + userId);
            return;
        }

        Property property = null;
        for (Property p : properties) {
            if (p.getPropertyId() == propertyId) {
                property = p;
                break;
            }
        }
        if (property == null) {
            System.out.println("Error: No property found with ID " + propertyId);
            return;
        }
        // Get booking details from the user
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the start date (dd/MM/yyyy): ");
        String startDateString = scanner.nextLine();
        System.out.println("Enter the end date (dd/MM/yyyy): ");
        String endDateString = scanner.nextLine();

        Date startDate;
        Date endDate;

        try {
            startDate = User.sdf.parse(startDateString);
            endDate = User.sdf.parse(endDateString);
        } catch (Exception e) {
            System.out.println("Error: Invalid date format");
            return;
        }
        System.out.print("Is the booking paid? (true/false): ");
        boolean isPaid = scanner.nextBoolean();
        Booking newBooking = new Booking();
        newBooking.setPaid(isPaid);
        newBooking.setStartDate(startDate);
        newBooking.setEndDate(endDate);
        if (user instanceof Costumer) {
            ((Costumer) user).getBookings().add(newBooking);
        } else {
            System.out.println("Error: User is not a customer");
        }

    }

    /**
     * this method calculates the booking cost
     * @param userId
     * @param propertyId
     */
    public void getBookingCost(int userId, int propertyId){
        // Find the user
        User user = null;
        for (User u : users) {
            if (u.getUserId() == userId) {
                user = u;
                break;
            }
        }
        //check if there is a user with that id.
        if (user == null) {
            System.out.println("Error: No user found with ID " + userId);
            return;
        }
        //check if the user is a costumer
        if (!(user instanceof Costumer)) {
            System.out.println("Error: User with ID " + userId + " is not a customer.");
            return;
        }

        //if the user id excites and user is a costumer
        Costumer customer = (Costumer) user;
        // Find all bookings for the given propertyId
        List<Booking> relevantBookings = new ArrayList<>();
        for (Booking booking : customer.getBookings()) {
            if (booking.getProperty().getPropertyId() == propertyId) {
                relevantBookings.add(booking);
            }
        }
        if (relevantBookings.isEmpty()) {
            System.out.println("No bookings found for the user ID " + userId + " and property ID " + propertyId);
        }
        else {
            for (Booking booking : relevantBookings){
                float cost = booking.calculateTotalCost();
                System.out.println("Booking from " + User.sdf.format(booking.getStartDate()) +
                        " to " + User.sdf.format(booking.getEndDate()) +
                        " has a total cost of: " + cost);

                }
            }



    }

    /**
     * this method get the user booking from its id
     * @param userId
     */
    public void getUserBooking(int userId){
        //check if there is a user with that id
        User user = null;
        for (User u : users) {
            if (u.getUserId() == userId) {
                user = u;
                break;
            }
        }
        //if there is no user with that id print the error message
        if (user == null) {
            System.out.println("Error: No user found with ID " + userId);
            return;
        }
        if (user instanceof Costumer){
            Costumer customer = (Costumer) user;
            List<Booking> bookings = customer.getBookings();
            if (bookings == null || bookings.isEmpty()) {
                System.out.println("No bookings found for the user with ID " + userId);
            }
            else{
                System.out.println("Booking Details for User ID " + userId + ":");
                for (Booking booking : bookings) {
                    System.out.println("Booking from " + User.sdf.format(booking.getStartDate()) +
                            " to " + User.sdf.format(booking.getEndDate()));
                }
            }
        }
        else{
            System.out.println("There is no customer with that user id");
            return;
        }
    }

    /**
     * this method compates two properties using thier ids
     * @param propertyId1
     * @param propertyId2
     */
    public void comparePropertyPricesPerDay(int propertyId1, int propertyId2) {
        Property property1 = null;
        Property property2 = null;

        // Find the properties by ID
        for (Property p : properties) {
            if (p.getPropertyId() == propertyId1) {
                property1 = p;
            } else if (p.getPropertyId() == propertyId2) {
                property2 = p;
            }
        }

        // Check if both properties were found
        if (property1 == null || property2 == null) {
            System.out.println("One or both property IDs not found.");
            return;
        }

        // Compare the two properties using compareTo
        int comparisonResult = property1.compareTo(property2);

        if (comparisonResult < 0) {
            System.out.println("Property ID " + propertyId1 + " is cheaper");
        } else if (comparisonResult > 0) {
            System.out.println("Property ID " + propertyId2 + " is cheaper");
        } else {
            System.out.println("Property ID " + propertyId1 + " and Property ID " + propertyId2 + " have the same rental price per day.");
        }
    }

    /**
     * this method terminates the application
     */
    public void exit() {
        System.out.println("Exiting the program.");
        System.exit(0);
    }

    /**
     * main of the  application , whole system
     * @param args
     */
    public static void main(String[] args){
        PopulateData populateData = new PopulateData();

        List<Property> properties = new ArrayList<>();
        List<User> users = new ArrayList<>();

        // Populate properties and users
        populateData.createHostsAndProperties(users, properties);
        populateData.createCustomersAndBookings(users, properties);

        System.out.println("Welcome to the BASIC Application!");
        Basic basicApp = new Basic();
        basicApp.menu();

    }

}
