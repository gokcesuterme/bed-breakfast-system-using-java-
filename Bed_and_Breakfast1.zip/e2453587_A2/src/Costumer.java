/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.Date;
import java.util.List;
public abstract class Costumer extends User{
    protected String preferredPaymentMethod;
    private List<Booking> bookings; // One customer can have many bookings

    public Costumer(String preferredPaymentMethod) {
        this.preferredPaymentMethod = preferredPaymentMethod;
    }

    public Costumer(int userId, Date dateOfBirth, String firstName, String lastName, Date registrationDate, String preferredPaymentMethod) {
        super(userId, dateOfBirth, firstName, lastName, registrationDate);
        this.preferredPaymentMethod = preferredPaymentMethod;
    }

    /**
     * This method is a getter for preffered payment method
     * @return String
     */

    public String getPreferredPaymentMethod() {
        return preferredPaymentMethod;
    }

    /**
     * this method is a setter for preferredPaymentMethod
     * @param preferredPaymentMethod
     */

    public void setPreferredPaymentMethod(String preferredPaymentMethod) {
        this.preferredPaymentMethod = preferredPaymentMethod;
    }

    /**
     * This method is getter for getting the bookings of an user
     * @return List
     */
    public List<Booking> getBookings() {
        return bookings;
    }

    /**
     * This method is setter for getting the bookings of an user
     * @param bookings
     */

    public void setBookings(List<Booking> bookings) {
        this.bookings = bookings;
    }

    /**
     * this methods is for calculating the discount percentage, later it will be iverriden by its subclasses
     * @return double
     */

    // Abstract method to get the discount percentage
    public abstract double getDiscountPercentage();
}
