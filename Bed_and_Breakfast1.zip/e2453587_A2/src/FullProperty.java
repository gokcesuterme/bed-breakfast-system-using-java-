/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */

import java.util.Date;
import java.util.HashMap;

public class FullProperty extends Property{
    private double propertySize;
    public FullProperty()
    {

    }

    public FullProperty(int propertyId, int noBedRooms, int noRooms, String city, HashMap<Date, String> propertyInspections, double pricePerDay, Host host) {
        super(propertyId, noBedRooms, noRooms, city, propertyInspections, pricePerDay, host);
    }

    public FullProperty(double propertySize) {
        this.propertySize = propertySize;
    }

    public FullProperty(int propertyId, int noBedRooms, int noRooms, String city, HashMap<Date, String> propertyInspections, double pricePerDay, Host host, double propertySize) {
        super(propertyId, noBedRooms, noRooms, city, propertyInspections, pricePerDay, host);
        this.propertySize = propertySize;
    }

    /**
     * this method gets the property size of the full property
     * @return dobule
     */
    public double getSize() {
        return propertySize;
    }

    /**
     * this method sets the property size of the full property
     * @param size
     */

    public void setSize(double size) {
        this.propertySize = size;
    }

    /**
     * this method calculates the price per day by overriding the upper class's method. Based on size of the property it calculates the tax rate.
     * @return double price per day
     */
    @Override
    public double calculatePricePerDay() {
        // Calculate the tax based on the property size
        double taxRate;
        if (propertySize <= 200) {
            taxRate = 1.01; // 1% tax for up to 200 m2
        } else if (propertySize <= 300) {
            taxRate = 1.03; // 3% tax for 200-300 m2
        } else {
            taxRate = 1.04; // 4% tax for above 300 m2
        }
        // Apply the tax rate to the pricePerDay
        return this.pricePerDay * taxRate;
    }


    @Override
    public String toString() {
        return "FullProperty{" +
                "propertyId=" + getPropertyId() +
                ", noBedRooms=" + getNoBedRooms() +
                ", city='" + getCity() + '\'' +
                ", pricePerDay=" + getPricePerDay() +
                ", propertySize=" + propertySize +
                ", host=" + getHost() +
                '}';
    }
}
