/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.Date;

public class Gold extends Costumer{
    private int goldLevel;

    //constructor
    public Gold(int userId, Date dateOfBirth, String firstName, String lastName, Date registrationDate, String preferredPaymentMethod, int goldLevel) {
        super(userId, dateOfBirth, firstName, lastName, registrationDate, preferredPaymentMethod);
        setGoldLevel(goldLevel);
    }
    //constructor
    public Gold(String preferredPaymentMethod, int goldLevel) {
        super(preferredPaymentMethod);
        this.goldLevel = goldLevel;
    }
    //getters and setters

    /**
     * this method is getter for the gold level of the costumer
     * @return int
     */
    public int getGoldLevel() {
        return goldLevel;
    }

    /**
     * this method is setter for the gold level of the costumer
     * @param goldLevel
     */

    public void setGoldLevel(int goldLevel) {
        //first check to see if the level is in the range
        if (goldLevel >= 1 && goldLevel <= 3) {
            this.goldLevel = goldLevel;
        } else {
            throw new IllegalArgumentException("Gold level must be in the range of 1 to 3.");
        }
    }

    /**
     * this method calculates the discount percentage by overriding.
     * @return double.
     */

    @Override
    public double getDiscountPercentage() {
        if (goldLevel < 1 || goldLevel > 3) {
            throw new IllegalStateException("Gold level is out of range. Valid range is 1 to 3.");
        }
        return goldLevel; //goldLevel is equal to the discount percentage.

    }

    /**
     * this method displays the Gold costumer details
     * @return String
     */
    @Override
    public String toString() {
        return "Gold{" +
                "userId=" + getUserId() +
                ", firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                ", dateOfBirth=" + sdf.format(getDateOfBirth()) +
                ", registrationDate=" + sdf.format(getRegistrationDate()) +
                ", preferredPaymentMethod='" + getPreferredPaymentMethod() + '\'' +
                ", goldLevel=" + goldLevel +
                '}';
    }
}
