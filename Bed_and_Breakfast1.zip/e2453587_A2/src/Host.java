/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.Date;

public class Host extends User{
    private double taxNumber;
    public Host()
    {

    }
    public Host(int userId, Date dateOfBirth, String firstName, String lastName, Date registrationDate) {
        super(userId, dateOfBirth, firstName, lastName, registrationDate);
    }
    //constructor
    public Host(int userId, Date dateOfBirth, String firstName, String lastName, Date registrationDate, double taxNumber) {
        super(userId, dateOfBirth, firstName, lastName, registrationDate);
        this.taxNumber = taxNumber;
    }
    //getters and setters

    /**
     * this method is getter for the tax number of a host
     * @return double
     */
    public double getTaxNumber() {
        return taxNumber;
    }

    /**
     * this method is a setter for the tax number of a host
     * @param taxNumber
     */

    public void setTaxNumber(double taxNumber) {
        this.taxNumber = taxNumber;
    }

    /**
     * this method displays the host details by overriding it
     * @return String
     */
    @Override
    public String toString() {
        return "Host{" +
                "userId=" + getUserId() +
                ", firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                ", dateOfBirth=" + sdf.format(getDateOfBirth()) +
                ", registrationDate=" + sdf.format(getRegistrationDate()) +
                ", taxNumber=" + taxNumber +
                '}';
    }
}
