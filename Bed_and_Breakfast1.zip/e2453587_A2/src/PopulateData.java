/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.ArrayList;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class PopulateData {
    /**
     * this method creates 3 instances of host and property
     * @param userList
     * @param propertyList
     */
    public static void createHostsAndProperties(List<User> userList, List<Property> propertyList) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            // Create hosts
            Host host1 = new Host(1, dateFormat.parse("10/10/1980"), "John", "Doe", dateFormat.parse("10/10/2020"), 12345);
            Host host2 = new Host(2, dateFormat.parse("15/05/1975"), "Jane", "Smith", dateFormat.parse("10/10/2021"), 67890);
            Host host3 = new Host(3, dateFormat.parse("20/12/1985"), "Emily", "Jones", dateFormat.parse("10/10/2022"), 13579);

            // Add hosts to user list
            userList.add(host1);
            userList.add(host2);
            userList.add(host3);

            // Create properties and associate each with a host
            // Create inspection HashMaps
            HashMap<Date, String> inspections1 = new HashMap<>();
            inspections1.put(dateFormat.parse("01/06/2023"), "“Broken toilet that needs to be fixed");

            HashMap<Date, String> inspections2 = new HashMap<>();
            inspections2.put(dateFormat.parse("15/06/2023"), "Safety and fire alarm check.");

            HashMap<Date, String> inspections3 = new HashMap<>();
            inspections3.put(dateFormat.parse("25/05/2023"), "It was in good condition");


            propertyList.add(new FullProperty(1, 3, 5, "İstanbul", inspections1, 100.0, host1, 500));
            propertyList.add(new SharedProperty(2, 2, 4, "Eskişehir", inspections2, 80.0, host2));
            propertyList.add(new FullProperty(3, 4, 6, "İzmir", inspections3, 120.0, host3, 700));

        } catch (ParseException e) {
            System.out.println("Error parsing the date: " + e.getMessage());
        }
    }

    /**
     * this method creates a 3 instances of booking and costumer
     * @param userList
     * @param propertyList
     */

    public static void createCustomersAndBookings(List<User> userList, List<Property> propertyList) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            // Create bookings for each property
            Booking booking1 = new Booking(true,dateFormat.parse("01/06/2023"), dateFormat.parse("10/06/2023"),propertyList.get(0));
            Booking booking2 = new Booking(false,dateFormat.parse("15/06/2023"), dateFormat.parse("20/06/2023"),propertyList.get(1));
            Booking booking3 = new Booking(true,dateFormat.parse("25/06/2023"), dateFormat.parse("30/06/2023"),propertyList.get(2));

            // Create customers and add bookings
            Costumer customer1 = new Gold(4, dateFormat.parse("27/07/1980"), "gökçesu", "terme", dateFormat.parse("15/01/2023"), "Credit Card", 1);
            customer1.getBookings().add(booking1);
            Costumer customer2 = new Standard(5, dateFormat.parse("15/03/1982"), "kutat", "terme", dateFormat.parse("20/02/2022"), "Paypal");
            customer2.getBookings().add(booking2);
            Costumer customer3 = new Gold(6, dateFormat.parse("05/08/1978"), "arda", "ünlüer", dateFormat.parse("25/03/2023"), "Cash", 2);
            customer3.getBookings().add(booking3);

            // Add customers to user list
            userList.add(customer1);
            userList.add(customer2);
            userList.add(customer3);

        } catch (ParseException e) {
            System.out.println("Error parsing the date: " + e.getMessage());
        }
    }
}