/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */

import java.util.Date;
import java.util.HashMap;

public class SharedProperty extends Property{
    public SharedProperty() {
    }

    public SharedProperty(int propertyId, int noBedRooms, int noRooms, String city, HashMap<Date, String> propertyInspections, double pricePerDay, Host host) {
        super(propertyId, noBedRooms, noRooms, city, propertyInspections, pricePerDay, host);
    }

    /**
     * this method ovverides the calculatePricePerDay. It divides the pricePerDay to noBedRooms;
     * @return double
     */


    @Override
    public double calculatePricePerDay() {
        return this.pricePerDay / this.noBedRooms;
    }

    /**
     * this method returns the details of the shared property
     * @return String
     */

    @Override
    public String toString() {
        return "SharedProperty{" +
                "propertyId=" + getPropertyId() +
                ", noBedRooms=" + getNoBedRooms() +
                ", city='" + getCity() + '\'' +
                ", pricePerDay=" + getPricePerDay() +
                ", host=" + getHost() +
                '}';
    }

}
