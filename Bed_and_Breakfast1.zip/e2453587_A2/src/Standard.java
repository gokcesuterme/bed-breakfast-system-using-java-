/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.Date;
import java.util.Calendar;

public class Standard extends Costumer {

    public Standard(int userId, Date dateOfBirth, String firstName, String lastName, Date registrationDate, String preferredPaymentMethod) {
        super(userId, dateOfBirth, firstName, lastName, registrationDate, preferredPaymentMethod);
    }

    /**
     *  this method overrides the getDiscountPercentage method in the upper class.
     * @return double
     */
    @Override
    public double getDiscountPercentage() {
        Calendar current = Calendar.getInstance();
        Calendar registration = Calendar.getInstance();
        registration.setTime(this.registrationDate);
        int years = current.get(Calendar.YEAR) - registration.get(Calendar.YEAR);
        if (registration.get(Calendar.DAY_OF_YEAR) > current.get(Calendar.DAY_OF_YEAR)) {
            years--;
        }
        // Check if the registration is 10 years or more
        return years >= 10 ? 2.0 : 0.0;
    }

    /**
     * this method displays the standard user informations
     * @return String
     */
    public String toString() {
        return "Standard{" +
                "userId=" + getUserId() +
                ", firstName='" + getFirstName() + '\'' +
                ", lastName='" + getLastName() + '\'' +
                ", dateOfBirth=" + sdf.format(getDateOfBirth()) +
                ", registrationDate=" + sdf.format(getRegistrationDate()) +
                ", preferredPaymentMethod='" + getPreferredPaymentMethod() + '\'' +
                '}';
    }
}
