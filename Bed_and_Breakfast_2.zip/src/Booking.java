/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Booking {
    private boolean isPaid;
    private Date startDate;
    private Date endDate;


    private Property property; //from the relation in the given class diagram. 1-1 relation between Booking and the Property.

    public Booking(){

    }

    public Booking(boolean isPaid, Date startDate, Date endDate) {
        this.isPaid = isPaid;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Booking(boolean isPaid, Date startDate, Date endDate, Property property) {
        this.isPaid = isPaid;
        this.startDate = startDate;
        this.endDate = endDate;
        this.property = property;
    }

    /**
     * this method is getter of isPaid
     * @return boolean is paid
     */

    public boolean isPaid() {
        return isPaid;
    }

    /**
     * this method is setter of isPaid
     * @param paid for is paid
     */

    public void setPaid(boolean paid) {
        isPaid = paid;
    }

    /**
     * this method is a getter for the start date for the booking
     * @return Date start date
     */

    public Date getStartDate() {
        return startDate;
    }

    /**
     * this method is a setter for the start date for the booking
     * @param startDate
     */

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * this method is a getter for the end date for the booking
     * @return Date end date
     */

    public Date getEndDate() {
        return endDate;
    }

    /**
     * this method is a setter for the end date for the booking
     * @param endDate
     */

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * this method gets a property
     * @return Property
     */
    public Property getProperty() {
        return property;
    }

    /**
     * this method sets a property
     * @param property
     */

    public void setProperty(Property property) {
        this.property = property;
    }

    /**
     * this method calculate the number of days between the start and the end date
     * @param start
     * @param end
     * @return long
     */

    private long calculateNumberOfDays(Date start, Date end) {
        long diffInMillies = end.getTime() - start.getTime();
        return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }

    /**
     * this method calculates the total cost of a booking by using the calculateNumberOfDays method and multiplying it with the price per day from the property
     * @return float total cost
     */
    public float calculateTotalCost() {
        long numberOfDays = calculateNumberOfDays(startDate, endDate);
        return (float) (numberOfDays * property.calculatePricePerDay());
    }
}
