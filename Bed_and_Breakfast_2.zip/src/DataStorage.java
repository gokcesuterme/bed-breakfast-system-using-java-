import java.util.ArrayList;
import java.sql.*;
import java.util.Objects;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DataStorage {
    private Connection connection;
    public DataStorage() {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/BasicDB", "cng443user", "1234");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection to database failed.");
            e.printStackTrace();
        }
    }

    // Method to read User data
    public ArrayList<User> readUsers() {
        ArrayList<User> users = new ArrayList<>();
        try {
            String query = "SELECT * FROM User";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int userId = resultSet.getInt("userID");
                Date dateOfBirth = resultSet.getDate("dateOfBirth");
                String firstName = resultSet.getString("firstName");
                String lastName = resultSet.getString("lastName");
                Date registrationDate = resultSet.getDate("registrationDate");
                String userType = resultSet.getString("type");

                switch (userType) {
                    case "h": // Host
                        double taxNumber = resultSet.getDouble("taxNumber"); // Assuming taxNumber is a column in your table
                        users.add(new Host(userId, dateOfBirth, firstName, lastName, registrationDate, taxNumber));
                        break;
                    case "g": // Gold
                        int goldLevel = resultSet.getInt("goldLevel"); // Assuming goldLevel is a column in your table
                        String preferredPaymentMethodGold = resultSet.getString("preferredPaymentMethod");
                        users.add(new Gold(userId, dateOfBirth, firstName, lastName, registrationDate, preferredPaymentMethodGold, goldLevel));
                        break;
                    case "s": // Standard
                        String preferredPaymentMethodStandard = resultSet.getString("preferredPaymentMethod");
                        users.add(new Standard(userId, dateOfBirth, firstName, lastName, registrationDate, preferredPaymentMethodStandard));
                        break;
                    default:
                        System.out.println("Error: Read User,Invalid User Entry! User type should be:h/g/s" );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
    public ArrayList<Property> readProperties() {
        ArrayList<Property> properties = new ArrayList<>();
        try {
            String query = "SELECT * FROM Property";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int propertyId = resultSet.getInt("propertyID");
                int noBedRooms = resultSet.getInt("noBedRooms");
                int noRooms = resultSet.getInt("noRooms");
                String city = resultSet.getString("city");
                double pricePerDay = resultSet.getDouble("pricePerDay");
                String propertyType = resultSet.getString("type");
                //I am using host in the all property constructors so here I make it null.
                if (propertyType.equals("f")) { // Full Property
                    double propertySize = resultSet.getDouble("propertySize");
                    properties.add(new FullProperty(propertyId, noBedRooms, noRooms, city, null, pricePerDay, null, propertySize));
                } else if (propertyType.equals("s")) { // Shared Property
                    properties.add(new SharedProperty(propertyId, noBedRooms, noRooms, city, null, pricePerDay, null));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return properties;
    }

    public void writeGoldUser(Gold goldUser) {
        try {
            // Check if the gold user already exists in the database
            String checkQuery = "SELECT COUNT(*) FROM User WHERE userID = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setInt(1, goldUser.getUserId());
            ResultSet resultSet = checkStmt.executeQuery();
            resultSet.next();
            int count = resultSet.getInt(1);

            String sql;
            if (count == 0) {
                // Insert new gold user
                sql = "INSERT INTO User (userID, dateOfBirth, firstName, lastName, registrationDate, type, preferredPaymentMethod, taxNumber, goldLevel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            } else {
                // Update existing gold user
                sql = "UPDATE User SET dateOfBirth = ?, firstName = ?, lastName = ?, registrationDate = ?, type = ?, preferredPaymentMethod = ?, taxNumber = ?, goldLevel = ? WHERE userID = ?";
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            // Setting the parameters for the prepared statement
            preparedStatement.setInt(count == 0 ? 1 : 9, goldUser.getUserId());
            preparedStatement.setDate(count == 0 ? 2 : 1, new java.sql.Date(goldUser.getDateOfBirth().getTime()));
            preparedStatement.setString(count == 0 ? 3 : 2, goldUser.getFirstName());
            preparedStatement.setString(count == 0 ? 4 : 3, goldUser.getLastName());
            preparedStatement.setDate(count == 0 ? 5 : 4, new java.sql.Date(goldUser.getRegistrationDate().getTime()));
            preparedStatement.setString(count == 0 ? 6 : 5, "g"); // 'g' for gold user
            preparedStatement.setString(count == 0 ? 7 : 6, goldUser.getPreferredPaymentMethod());
            preparedStatement.setNull(count == 0 ? 8 : 7, java.sql.Types.DOUBLE); // Explicitly setting taxNumber to NULL
            preparedStatement.setInt(count == 0 ? 9 : 8, goldUser.getGoldLevel());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Method to write a Standard user
    public void writeStandardUser(Standard standardUser) {
        try {
            // Check if the standard user already exists in the database
            String checkQuery = "SELECT COUNT(*) FROM User WHERE userID = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setInt(1, standardUser.getUserId());
            ResultSet resultSet = checkStmt.executeQuery();
            resultSet.next();
            int count = resultSet.getInt(1);

            String sql;
            if (count == 0) {
                // Insert new standard user
                sql = "INSERT INTO User (userID, dateOfBirth, firstName, lastName, registrationDate, type, preferredPaymentMethod, taxNumber, goldLevel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            } else {
                // Update existing standard user
                sql = "UPDATE User SET dateOfBirth = ?, firstName = ?, lastName = ?, registrationDate = ?, type = ?, preferredPaymentMethod = ?, taxNumber = ?, goldLevel = ? WHERE userID = ?";
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            // Setting the parameters for the prepared statement
            preparedStatement.setInt(count == 0 ? 1 : 9, standardUser.getUserId());
            preparedStatement.setDate(count == 0 ? 2 : 1, new java.sql.Date(standardUser.getDateOfBirth().getTime()));
            preparedStatement.setString(count == 0 ? 3 : 2, standardUser.getFirstName());
            preparedStatement.setString(count == 0 ? 4 : 3, standardUser.getLastName());
            preparedStatement.setDate(count == 0 ? 5 : 4, new java.sql.Date(standardUser.getRegistrationDate().getTime()));
            preparedStatement.setString(count == 0 ? 6 : 5, "s"); // 's' for standard user
            preparedStatement.setString(count == 0 ? 7 : 6, standardUser.getPreferredPaymentMethod());
            preparedStatement.setNull(count == 0 ? 8 : 7, java.sql.Types.DOUBLE); // Setting taxNumber to NULL
            preparedStatement.setNull(count == 0 ? 9 : 8, java.sql.Types.INTEGER); // Setting goldLevel to NULL

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Method to write a Host user
    public void writeHost(Host hostUser) {
        try {
            // Check if the host user already exists in the database
            String checkQuery = "SELECT COUNT(*) FROM User WHERE userID = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setInt(1, hostUser.getUserId());
            ResultSet resultSet = checkStmt.executeQuery();
            resultSet.next();
            int count = resultSet.getInt(1);

            String sql;
            if (count == 0) {
                // Insert new host user
                sql = "INSERT INTO User (userID, dateOfBirth, firstName, lastName, registrationDate, type, preferredPaymentMethod, taxNumber, goldLevel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            } else {
                // Update existing host user
                sql = "UPDATE User SET dateOfBirth = ?, firstName = ?, lastName = ?, registrationDate = ?, type = ?, preferredPaymentMethod = ?, taxNumber = ?, goldLevel = ? WHERE userID = ?";
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            // Setting the parameters for the prepared statement
            preparedStatement.setInt(count == 0 ? 1 : 9, hostUser.getUserId());
            preparedStatement.setDate(count == 0 ? 2 : 1, new java.sql.Date(hostUser.getDateOfBirth().getTime()));
            preparedStatement.setString(count == 0 ? 3 : 2, hostUser.getFirstName());
            preparedStatement.setString(count == 0 ? 4 : 3, hostUser.getLastName());
            preparedStatement.setDate(count == 0 ? 5 : 4, new java.sql.Date(hostUser.getRegistrationDate().getTime()));
            preparedStatement.setString(count == 0 ? 6 : 5, "h"); // 'h' for host user
            preparedStatement.setString(count == 0 ? 7 : 6, null); // Assuming Hosts don't have a preferred payment method
            preparedStatement.setDouble(count == 0 ? 8 : 7, hostUser.getTaxNumber());
            preparedStatement.setNull(count == 0 ? 9 : 8, java.sql.Types.INTEGER); // Setting goldLevel to NULL

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to write a Shared Property
    public void writeSharedProperty(SharedProperty sharedProperty) {
        try {
            // Check if the shared property already exists in the database
            String checkQuery = "SELECT COUNT(*) FROM Property WHERE propertyID = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setInt(1, sharedProperty.getPropertyId());
            ResultSet resultSet = checkStmt.executeQuery();
            resultSet.next();
            int count = resultSet.getInt(1);

            String sql;
            if (count == 0) {
                // Insert new shared property
                sql = "INSERT INTO Property (propertyID, noBedRooms, noRooms, city, pricePerDay, type, propertySize) VALUES (?, ?, ?, ?, ?, ?, NULL)";
            } else {
                // Update existing shared property
                sql = "UPDATE Property SET noBedRooms = ?, noRooms = ?, city = ?, pricePerDay = ?, type = ?, propertySize = NULL WHERE propertyID = ?";
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            // Setting the parameters for the prepared statement
            if (count == 0) { // For INSERT
                preparedStatement.setInt(1, sharedProperty.getPropertyId());
                preparedStatement.setInt(2, sharedProperty.getNoBedRooms());
                preparedStatement.setInt(3, sharedProperty.getNoRooms());
                preparedStatement.setString(4, sharedProperty.getCity());
                preparedStatement.setDouble(5, sharedProperty.getPricePerDay());
                preparedStatement.setString(6, "s"); // 's' for shared property
                // propertySize is already set to NULL in the SQL query
            } else { // For UPDATE
                preparedStatement.setInt(1, sharedProperty.getNoBedRooms());
                preparedStatement.setInt(2, sharedProperty.getNoRooms());
                preparedStatement.setString(3, sharedProperty.getCity());
                preparedStatement.setDouble(4, sharedProperty.getPricePerDay());
                preparedStatement.setString(5, "s"); // 's' for shared property
                preparedStatement.setInt(6, sharedProperty.getPropertyId());
                // propertySize is already set to NULL in the SQL query
            }

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to write a Full Property
    public void writeFullProperty(FullProperty fullProperty) {
        try {
            // Check if the full property already exists in the database
            String checkQuery = "SELECT COUNT(*) FROM Property WHERE propertyID = ?";
            PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
            checkStmt.setInt(1, fullProperty.getPropertyId());
            ResultSet resultSet = checkStmt.executeQuery();
            resultSet.next();
            int count = resultSet.getInt(1);

            String sql;
            if (count == 0) {
                // Insert new full property
                sql = "INSERT INTO Property (propertyID, noBedRooms, noRooms, city, pricePerDay, type, propertySize) VALUES (?, ?, ?, ?, ?, ?, ?)";
            } else {
                // Update existing full property
                sql = "UPDATE Property SET noBedRooms = ?, noRooms = ?, city = ?, pricePerDay = ?, type = ?, propertySize = ? WHERE propertyID = ?";
            }

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            // Setting the parameters for the prepared statement
            if (count == 0) { // For INSERT
                preparedStatement.setInt(1, fullProperty.getPropertyId());
                preparedStatement.setInt(2, fullProperty.getNoBedRooms());
                preparedStatement.setInt(3, fullProperty.getNoRooms());
                preparedStatement.setString(4, fullProperty.getCity());
                preparedStatement.setDouble(5, fullProperty.getPricePerDay());
                preparedStatement.setString(6, "f"); // 'f' for full property
                preparedStatement.setDouble(7, fullProperty.getSize()); // Setting propertySize
            } else { // For UPDATE
                preparedStatement.setInt(1, fullProperty.getNoBedRooms());
                preparedStatement.setInt(2, fullProperty.getNoRooms());
                preparedStatement.setString(3, fullProperty.getCity());
                preparedStatement.setDouble(4, fullProperty.getPricePerDay());
                preparedStatement.setString(5, "f"); // 'f' for full property
                preparedStatement.setDouble(6, fullProperty.getSize()); // Setting propertySize
                preparedStatement.setInt(7, fullProperty.getPropertyId());
            }

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to close the database connection
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
