/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
import java.util.Date;
import java.util.HashMap;
import java.io.Serializable;
public abstract class Property implements PropertyPrice,Comparable<Property> {
    protected int propertyId;
    protected int noBedRooms;
    protected int noRooms;
    protected String city;
    protected HashMap<Date, String> propertyInspections = new HashMap<>();
    protected double pricePerDay;

    protected Host host; // Each property has one host

    public Property()
    {

    }
    public Property(int propertyId, int noBedRooms, int noRooms, String city, HashMap<Date, String> propertyInspections, double pricePerDay, Host host) {
        this.propertyId = propertyId;
        this.noBedRooms = noBedRooms;
        this.noRooms = noRooms;
        this.city = city;
        this.propertyInspections = propertyInspections;
        this.pricePerDay = pricePerDay;
        this.host = host;

    }

    /**
     * this method is a setter for the property id
     * @param propertyId
     */
    public void setPropertyId(int propertyId) {
        this.propertyId = propertyId;
    }

    /**
     * this method is a getter for the property id
     * @return int
     */

    public int getPropertyId() {
        return propertyId;
    }

    /**
     * this method is a getter for the number of bedrooms in a property
     * @return int
     */

    public int getNoBedRooms() {
        return noBedRooms;
    }

    /**
     * this method is a setter for num of bedrooms
     * @param noBedRooms
     */

    public void setNoBedRooms(int noBedRooms) {
        this.noBedRooms = noBedRooms;
    }

    /**
     * this method is getter for num of rooms
     * @return int
     */

    public int getNoRooms() {
        return noRooms;
    }

    /**
     * this method is a setter for num of rooms
     * @param noRooms
     */

    public void setNoRooms(int noRooms) {
        this.noRooms = noRooms;
    }

    /**
     * this method is a getter for the city name
     * @return String
     */

    public String getCity() {
        return city;
    }

    /**
     * this method is a setter for city name
     * @param city
     */

    public void setCity(String city) {
        this.city = city;
    }

    /**
     * this method is a getter for propertyInspections
     * @return HashMap
     */

    public HashMap<Date, String> getPropertyInspections() {
        return propertyInspections;
    }

    /**
     * this method is a setter for propertyInspections
     * @param propertyInspections
     */

    public void setPropertyInspections(HashMap<Date, String> propertyInspections) {
        this.propertyInspections = propertyInspections;
    }

    /**
     * this method Inspections
     * @param date
     * @param inspectionText
     */

    public void addInspection(Date date, String inspectionText) {
        propertyInspections.put(date, inspectionText);
    }

    /**
     * this method is a getter for price per day
     * @return double
     */

    public double getPricePerDay() {
        return pricePerDay;
    }

    /**
     * this method is a setter for price per day
     * @param pricePerDay
     */

    public void setPricePerDay(double pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    /**
     * this method returns the host
     * @return Host
     */

    public Host getHost() {
        return host;
    }

    /**
     * setter for host. this methos sets a host
     * @param host
     */

    public void setHost(Host host) {
        this.host = host;
    }

    /**
     * this method compares the two properties prices by the method calculatePricePerDay
     * @param otherProperty the object to be compared.
     * @return int
     */
    @Override
    public int compareTo(Property otherProperty) {
        // Use the calculatePricePerDay method to compare properties
        double pricePerDayThis = this.calculatePricePerDay();
        double pricePerDayOther = otherProperty.calculatePricePerDay();

        // If this property is cheaper, return a negative number
        if (pricePerDayThis < pricePerDayOther) {
            return -1;
        }
        // If they are the same price, return 0
        else if (pricePerDayThis == pricePerDayOther) {
            return 0;
        }
        // If this property is more expensive, return a positive number
        else {
            return 1;
        }
    }


}
