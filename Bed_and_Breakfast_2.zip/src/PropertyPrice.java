/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */
public interface PropertyPrice {
    /**
     * this method is going to overridden int class property.
     * @return double
     */

    double calculatePricePerDay();
}
