/**
 * @author Gökçesu Terme
 * @version SDK 21.0
 */

import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.Serializable;

public abstract class User implements Serializable {
    protected static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    protected int userId;
    protected Date dateOfBirth;
    protected String firstName;
    protected String lastName;
    protected Date registrationDate;

    //no argument constructor
    public User()
    {

    }
    //constructor

    /**
     * this is a constructor for the user
     * @param userId
     * @param dateOfBirth
     * @param firstName
     * @param lastName
     * @param registrationDate
     */
    public User(int userId, Date dateOfBirth, String firstName, String lastName, Date registrationDate) {
        this.userId = userId;
        this.dateOfBirth = dateOfBirth;
        this.firstName = firstName;
        this.lastName = lastName;
        this.registrationDate = registrationDate;
    }

    /**
     * this method is a getter for getting the user id
     * @return int id of the user
     */
    //getters and setters
    public int getUserId() {
        return userId;
    }

    /**
     * this method is setter for user id
     * @param userId id of the user
     */

    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * this methos is a getter for dob
     * @return Date dpb of the user
     */

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * this method is a setter for dob of the user
     * @param dateOfBirth dob of the user
     */

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * this method is a getter for the first name of the user
     * @return String first name of the user
     */

    public String getFirstName() {
        return firstName;
    }

    /**
     * this method is a setter for the first name of the user
     * @param firstName first name of the user
     */

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * this method is a getter for last name of the user
     * @return String last name of the user
     */

    public String getLastName() {
        return lastName;
    }

    /**
     * this method is a setter for the last name of the user
     * @param lastName last name of the user
     */

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * this method is a getter of the registration date for the user
     * @return Date reg date of the user
     */

    public Date getRegistrationDate() {
        return registrationDate;
    }

    /**
     * this method is a setter for registration for the user
     * @param registrationDate reg date of the user
     */

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }
}
